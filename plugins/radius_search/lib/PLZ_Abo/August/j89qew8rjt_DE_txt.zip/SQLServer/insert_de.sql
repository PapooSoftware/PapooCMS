USE myDBname
BULK
INSERT de
FROM 'C:\de_complete.txt'
WITH
(
FIRSTROW = 2,
FIELDTERMINATOR = ';',
ROWTERMINATOR = '\n',
CODEPAGE = 'ACP'
)
GO