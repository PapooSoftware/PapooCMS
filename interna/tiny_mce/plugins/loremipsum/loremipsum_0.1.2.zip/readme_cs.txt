Lorem Ipsum plug-in pro TinyMCE verze 3.x
-----------------------------------------
$Id: readme_cs.txt 11 2009-04-30 23:33:24Z scholzj $

Verze:
	0.1.2

Autor:
	Jakub Scholz (zalozeno na podobnem pluginu od Gusztav Palvolgyi pro TinyMCE 1.x & 2.x)
	Spanelsky a Katalansky preklad vytvoril Jordi Llonch
	Nemecky preklad a lorem ipsum text vytvoril a dodal Cyrill Gross

URL:
	http://www.assembla.com/spaces/lorem-ipsum

O pluginu:
  Plugin generuje text pro vyplneni Vasich stranek. Je uzitecny pri testovani editoru, stranky a/nebo CMS systemu.
  Vice info o tom co je to "Lorem Ipsum" naleznete na http://www.lipsum.com/

Kompatibilita:
  Testovano v IE7, FF3.0.9 a O9.63 s TinyMCE 3.2.2.3

Instalace:
  * Zkopirujte loremipsum adresar do TinyMCE adresare s pluginy
	* Pridejte plugin do seznamu nacitanych pluginu
  		priklad: plugins : "loremipsum"
  * Pridejte tlacitko na listu
  		priklad: theme_advanced_buttons3_add : "loremipsum"