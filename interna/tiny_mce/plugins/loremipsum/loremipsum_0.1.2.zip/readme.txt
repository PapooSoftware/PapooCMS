Lorem Ipsum plug-in for TinyMCE version 3.x
-------------------------------------------
$Id: readme.txt 11 2009-04-30 23:33:24Z scholzj $

Version:
	0.1.2

Author:
	Jakub Scholz (heavily based on similar plug-in from Gusztav Palvolgyi for TinyMCE 1.x & 2.x)
	Spanish and Catalan translation created and submited by Jordi Llonch
	German translation and lorem ipsum text was created and submited by Cyrill Gross

URL:
	http://www.assembla.com/spaces/lorem-ipsum

About:
  This plug-in generates dummy text for your web pages. Useful during testing the editor, website and/or CMS systems.
  More info on what 'Lorem ipsum' is can be found here: http://www.lipsum.com/

Adding own text or language pack:
  Feel free to contribute with your own language packs or source texts

Compatibility:
  Tested in IE7, FF3.0.9 and O9.63 with TinyMCE 3.2.2.3

Installation instructions:
  * Copy the loremipsum directory to the plugins directory of TinyMCE
  * Add plugin to TinyMCE plug-in option list
  		example: plugins : "loremipsum"
  * Add button to TinyMCE button list
  		example: theme_advanced_buttons3_add : "loremipsum"