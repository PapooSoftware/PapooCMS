/**
 * Lorem Ipsum plug-in for TinyMCE version 3.x
 * -------------------------------------------
 * $Id: es.js 6 2008-06-18 08:56:05Z scholzj $
 *
 * @author     Jordi Llonch
 * @version    $Rev: 6 $
 * @package    LoremIpsum
 * @link       http://www.assembla.com/spaces/lorem-ipsum
 */

tinyMCE.addI18n('es.loremipsum',{
	desc : 'Lorem Ipsum'
});
